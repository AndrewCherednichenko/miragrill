export default function NotFound() {
  return (
    <h1>НЭТУ СТРАНИЦЫ БРАТ!</h1>
  );
}
